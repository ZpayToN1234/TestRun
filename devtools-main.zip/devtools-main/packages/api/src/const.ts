export const HOOK_SETUP = 'devtools-plugin:setup'
export const HOOK_PLUGIN_SETTINGS_SET = 'plugin:settings:set'
