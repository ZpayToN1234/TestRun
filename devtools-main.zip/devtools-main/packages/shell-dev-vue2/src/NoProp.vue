<template>
  <div>{{ someArray }}</div>
</template>

<script>
export default {
  data () {
    return {
      someArray: [1, 2]
    }
  }
}
</script>
