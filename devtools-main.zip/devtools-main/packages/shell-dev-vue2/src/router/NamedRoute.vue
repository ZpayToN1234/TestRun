<template>
  <div>
    <p>Hello named route</p>
  </div>
</template>

<script>
export default {
}
</script>
