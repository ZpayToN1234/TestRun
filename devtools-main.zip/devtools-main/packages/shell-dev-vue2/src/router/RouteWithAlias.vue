<template>
  <div>
    <p>Hello from route with alias</p>
  </div>
</template>

<script>
export default {
}
</script>
