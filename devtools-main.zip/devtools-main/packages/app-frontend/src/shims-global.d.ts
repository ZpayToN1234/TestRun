declare const Headway: any

// @TODO remove
declare const browser: any
